#include <iostream>
using namespace std;

/*
This program should get the user's input
of y or n, and then the program should
repeat what the user's decision was.
*/

char GetYesOrNo()
{
    cout << "(y/n): ";
    char c;
    cin >> c;
    while ( c != 'y' && c != 'n' )
    {
        cout << "Invalid try again: ";
        cin >> c;
    }
}

int main()
{
    char choice = ' ';
    cout << "What is your choice?" << endl;
    choice = GetYesOrNo();

    cout << "Choice was: " << choice << endl;

    return 0;
}
