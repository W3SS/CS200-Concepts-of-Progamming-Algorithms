#include <iostream>
using namespace std;

/*
This program should have the user enter
3 prices before continuing.
*/

int main()
{
    const int MAX = 3;

    float prices[MAX];

    for ( int i = 0; i <= MAX; i++ )
    {
        cout << "Enter price #" << i << ": ";
        cin >> prices[i];
    }

    cout << "Program done." << endl;

    return 0;
}
