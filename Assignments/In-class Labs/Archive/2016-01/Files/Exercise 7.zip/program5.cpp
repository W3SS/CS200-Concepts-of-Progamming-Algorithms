#include <iostream>
using namespace std;

/*
For this program, it should take in an array
and display all the contents in reverse order,
from last to first.
*/

void Display( string arr[], int size )
{
    for ( int i = size; i > 0; i-- )
    {
        cout << i << ". " << arr[i] << endl;
    }
}

int main()
{
    string names[] = {
        "shinee",
        "2ne1",
        "f(x)"
        };

    Display( names, 3 );

    return 0;
}
