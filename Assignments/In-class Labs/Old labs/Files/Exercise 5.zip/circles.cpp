#include <iostream>
using namespace std;

int main()
{
    bool done = false;
    const float pi = 3.14159;
    float radius;

    while ( !done )
    {
        cout << endl;
        cout << "What is the circle radius? ";
        cin >> radius;

        // Functionize this calculation
        float circumference = 2 * pi * radius;

        // Functionize this calculation
        float perimeter = pi * radius * radius;

        cout << "Circumference: " << circumference << endl;
        cout << "Perimeter: " << perimeter << endl;
    }

    return 0;
}
