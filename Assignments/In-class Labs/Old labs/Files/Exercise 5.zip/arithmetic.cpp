#include <iostream>
using namespace std;

int main()
{
    bool done = false;
    while ( !done )
    {
        // Functionize this menu
        cout << endl;
        cout << "1. Add" << endl;
        cout << "2. Subtract" << endl;
        cout << "3. Multiply" << endl;
        cout << "4. Divide" << endl;

        int choice;
        // Functionize this input & validation
        cout << "Choice: ";
        cin >> choice;
        while ( choice < 1 || choice > 4 )
        {
            cout << "Invalid choice. Try again: " << endl;
            cin >> choice;
        }

        if ( choice == 1 )
        {
            // Functionize this
            int num1, num2;
            cout << "Enter two numbers: ";
            cin >> num1 >> num2;
            cout << (num1 + num2) << endl;
        }
        else if ( choice == 2 )
        {
            // Functionize this
            int num1, num2;
            cout << "Enter two numbers: ";
            cin >> num1 >> num2;
            cout << (num1 - num2) << endl;
        }
        else if ( choice == 3 )
        {
            // Functionize this
            int num1, num2;
            cout << "Enter two numbers: ";
            cin >> num1 >> num2;
            cout << (num1 * num2) << endl;
        }
        else if ( choice == 4 )
        {
            // Functionize this
            int num1, num2;
            cout << "Enter two numbers: ";
            cin >> num1 >> num2;
            cout << (num1 / num2) << endl;
        }
    }

    return 0;
}

