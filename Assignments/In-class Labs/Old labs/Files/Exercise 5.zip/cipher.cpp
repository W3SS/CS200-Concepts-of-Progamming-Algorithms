#include <iostream>
#include <string>
using namespace std;

int main()
{
    bool done = false;
    while ( !done )
    {
        cout << "Enter a word: ";
        string originalWord;
        cin >> originalWord;

        cout << "Enter a cipher key: ";
        int key;
        cin >> key;

        string secretWord = "";

        for ( int i = 0; i < originalWord.size(); i++ )
        {
            // Functionize this
            char currentLetter = toupper( originalWord[i] );
            int offsetNumber = currentLetter + key;
            if ( offsetNumber > 90 )
            {
                offsetNumber -= 25;
            }
            char offsetChar = char(offsetNumber);
            
            secretWord += offsetChar;
        }

        cout << "Secret Word: " << secretWord << endl << endl;
    }

    return 0;
}

