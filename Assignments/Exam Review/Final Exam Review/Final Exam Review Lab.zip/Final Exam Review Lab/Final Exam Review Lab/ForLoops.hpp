#ifndef FOR_LOOPS_HPP
#define FOR_LOOPS_HPP

#include <string>
using namespace std;


#endif