#ifndef INHERITANCE_HPP
#define INHERITANCE_HPP

#include <string>
#include <iostream>
using namespace std;


#endif