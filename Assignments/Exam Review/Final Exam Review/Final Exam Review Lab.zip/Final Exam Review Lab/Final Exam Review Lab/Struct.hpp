#ifndef STRUCT_HPP
#define STRUCT_HPP



#endif