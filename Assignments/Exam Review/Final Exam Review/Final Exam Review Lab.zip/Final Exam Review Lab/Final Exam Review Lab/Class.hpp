#ifndef CLASS_HPP
#define CLASS_HPP

#include <string>
using namespace std;


#endif