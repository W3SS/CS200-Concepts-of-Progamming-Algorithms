#include <iostream>
#include <string>
using namespace std;

//#include "Tester_IfStatements.hpp"
//#include "Tester_ForLoops.hpp"
//#include "Tester_Struct.hpp"
//#include "Tester_Class.hpp"
//#include "Tester_Inheritance.hpp"

int main()
{
	//IfStatementTester::Start();

	//ForLoopTester::Start();

	//StructTester::Start();

	//ClassTester::Start();

	//InheritanceTester::Start();


	cout << "End of program" << endl;
	while (true) {}

	return 0;
}